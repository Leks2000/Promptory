  (function() {
    if (typeof gsap === 'undefined') return;
    gsap.registerPlugin(ScrollTrigger);
    
    // Container entrance
    gsap.from('.container, .options-container, .main', { opacity: 0, y: 20, duration: 0.5, ease: 'power3.out' });
    
    // Header
    gsap.from('h1, .header', { y: -30, opacity: 0, duration: 0.5, delay: 0.1, ease: 'back.out(2)' });
    
    // Sections stagger
    gsap.utils.toArray('.section, .setting-group, .option-group, .card').forEach(function(s, i) {
      gsap.from(s, {
        scrollTrigger: { trigger: s, start: 'top 92%', toggleActions: 'play none none reverse' },
        y: 25, opacity: 0, duration: 0.4, delay: i * 0.05, ease: 'power3.out'
      });
    });
    
    // Buttons bounce in
    gsap.from('.btn, button', {
      scale: 0.9, opacity: 0, stagger: 0.05, duration: 0.3, delay: 0.4, ease: 'back.out(2)'
    });
    
    // Toggle switches
    document.querySelectorAll('.switch, input[type="checkbox"]').forEach(function(sw) {
      sw.addEventListener('change', function() {
        gsap.fromTo(this.closest('.setting-group, .option-group') || this.parentElement,
          { scale: 0.98 },
          { scale: 1, duration: 0.3, ease: 'elastic.out(1, 0.5)' }
        );
      });
    });
    
    console.log('GSAP Options page animations loaded');
  })();