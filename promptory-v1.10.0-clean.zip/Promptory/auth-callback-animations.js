(function() {
  if (typeof gsap === 'undefined') return;
  gsap.from('.container, .card, .auth-card', { scale: 0.9, opacity: 0, duration: 0.6, ease: 'back.out(1.7)' });
  gsap.from('h1, h2', { y: -20, opacity: 0, duration: 0.5, delay: 0.2, ease: 'power3.out' });
  gsap.from('p', { y: 10, opacity: 0, duration: 0.4, delay: 0.3, ease: 'power2.out' });
  var spinner = document.querySelector('.spinner, .loading');
  if (spinner) {
    gsap.to(spinner, { rotation: 360, duration: 1, repeat: -1, ease: 'linear' });
  }
})();
