  (function() {
    if (typeof gsap === 'undefined') return;
    
    const tl = gsap.timeline({ defaults: { ease: 'power3.out' } });
    
    // Container fade in
    tl.from('.container', { opacity: 0, scale: 0.9, duration: 0.6, ease: 'back.out(1.7)' })
    
    // Logo: 3D spin-in
    .from('.logo', {
      scale: 0,
      rotation: -360,
      opacity: 0,
      duration: 0.8,
      ease: 'back.out(2.5)'
    }, '-=0.3')
    
    // Logo continuous float (enhanced version)
    .to('.logo', {
      y: -8,
      duration: 2.5,
      repeat: -1,
      yoyo: true,
      ease: 'sine.inOut'
    })
    
    // Title: slide up with blur
    .from('h1', {
      y: 40,
      opacity: 0,
      filter: 'blur(10px)',
      duration: 0.6,
    }, '-=2.5')
    
    // Subtitle
    .from('.subtitle', {
      y: 20,
      opacity: 0,
      duration: 0.5,
    }, '-=2')
    
    // Terms section: slide in from left
    .from('.terms-section', {
      x: -40,
      opacity: 0,
      duration: 0.5,
      ease: 'back.out(1.5)'
    }, '-=1.5')
    
    // Google button: bounce in
    .from('.btn-google', {
      scale: 0.5,
      opacity: 0,
      duration: 0.5,
      ease: 'back.out(3)'
    }, '-=1')
    
    // Hint text
    .from('.btn-google-hint', {
      y: 10,
      opacity: 0,
      duration: 0.3,
    }, '-=0.6')
    
    // Skip button
    .from('.btn-skip', {
      y: 10,
      opacity: 0,
      duration: 0.3,
    }, '-=0.3');
    
    // Google button glow pulse
    gsap.to('.btn-google:not(:disabled)', {
      boxShadow: '0 0 25px rgba(108, 92, 231, 0.5)',
      duration: 1.5,
      repeat: -1,
      yoyo: true,
      ease: 'sine.inOut',
      delay: 2
    });
    
    // Hover effects
    document.querySelector('.btn-google')?.addEventListener('mouseenter', function() {
      if (!this.disabled) {
        gsap.to(this, { scale: 1.03, duration: 0.25, ease: 'power2.out' });
      }
    });
    document.querySelector('.btn-google')?.addEventListener('mouseleave', function() {
      gsap.to(this, { scale: 1, duration: 0.3, ease: 'elastic.out(1, 0.5)' });
    });
    
    document.querySelector('.btn-skip')?.addEventListener('mouseenter', function() {
      if (!this.disabled) {
        gsap.to(this, { scale: 1.05, color: 'var(--accent)', duration: 0.2 });
      }
    });
    document.querySelector('.btn-skip')?.addEventListener('mouseleave', function() {
      gsap.to(this, { scale: 1, color: '', duration: 0.3, clearProps: 'color' });
    });
    
    // Checkbox interaction
    document.getElementById('age-terms-checkbox')?.addEventListener('change', function() {
      if (this.checked) {
        gsap.fromTo('.btn-google', { scale: 0.95 }, { scale: 1, duration: 0.4, ease: 'elastic.out(1.2, 0.5)' });
        gsap.fromTo('.btn-skip', { scale: 0.95 }, { scale: 1, duration: 0.4, ease: 'elastic.out(1.2, 0.5)' });
      }
    });
    
    // Background particles
    const particleCount = 20;
    for (let i = 0; i < particleCount; i++) {
      const dot = document.createElement('div');
      const size = gsap.utils.random(2, 5);
      dot.style.cssText = `
        position: fixed; width: ${size}px; height: ${size}px;
        background: rgba(var(--accent-rgb), ${gsap.utils.random(0.1, 0.3)});
        border-radius: 50%; pointer-events: none; z-index: 0;
        left: ${gsap.utils.random(0, 100)}%; top: ${gsap.utils.random(0, 100)}%;
      `;
      document.body.appendChild(dot);
      
      gsap.to(dot, {
        y: gsap.utils.random(-50, 50),
        x: gsap.utils.random(-30, 30),
        duration: gsap.utils.random(3, 8),
        repeat: -1,
        yoyo: true,
        ease: 'sine.inOut',
        delay: gsap.utils.random(0, 3)
      });
    }
    
    console.log('GSAP Welcome page animations loaded');
  })();